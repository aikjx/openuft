# GAQ 常数几何化体系

编号：`s08_gaq_geometrized_constants`；类型：`extension_candidate`。

基础前提：v5 将 c、hbar 的独立地位改写为几何关系；与 v4 分开审查。

独立管理公设、推导、代码、数据、结论及发布，不继承其他体系的证据等级。当前科学状态：待审查；空模板不表示研究完成。

[体系身份](system.json) · [来源与谱系](sources.md) · [体系总表](../README.md)

| 生命周期 | 入口 |
|---|---|
| 00_project | [说明](00_project/README.md) |
| 01_literature | [说明](01_literature/README.md) |
| 02_assumptions | [说明](02_assumptions/README.md) |
| 03_formalism | [说明](03_formalism/README.md) |
| 04_derivations | [说明](04_derivations/README.md) |
| 05_consistency | [说明](05_consistency/README.md) |
| 06_predictions | [说明](06_predictions/README.md) |
| 07_computation | [说明](07_computation/README.md) |
| 08_data | [说明](08_data/README.md) |
| 09_validation | [说明](09_validation/README.md) |
| 10_uncertainty | [说明](10_uncertainty/README.md) |
| 11_falsification | [说明](11_falsification/README.md) |
| 12_conclusions | [说明](12_conclusions/README.md) |
| 13_publications | [说明](13_publications/README.md) |
| 14_review | [说明](14_review/README.md) |
| 15_releases | [说明](15_releases/README.md) |
| 90_archive | [说明](90_archive/README.md) |

上游体系：[s07_gaq_complex_curvature](../s07_gaq_complex_curvature/README.md)
