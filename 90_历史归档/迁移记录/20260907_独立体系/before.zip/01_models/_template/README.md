# 新假设路线模板 · _template


> 这是新假设体系的脚手架。复制本目录为 `h07_xxx/`，逐阶段填充，并登记于 `01_hypotheses/README.md`。

## 研究问题

（一句话：本体系试图用何种机制 / 世界观产生并统一场？）

## 状态

待建模 / 进行中 / 已收敛 / 已淘汰。下列历史关联材料尚未逐项核实，不能据此宣布该路线成立。



本次仅完成研究组织与复现路径整理；历史正文的科学主张尚未重新审定。身份与假设边界见 [model.json](model.json)。

| 目录 | 职责 |
|---|---|
| [00_project](00_project/README.md) | 立项与研究计划 |
| [01_literature](01_literature/README.md) | 文献与基准理论 |
| [02_assumptions](02_assumptions/README.md) | 宇宙模型与假设 |
| [03_formalism](03_formalism/README.md) | 数学形式与定义 |
| [04_derivations](04_derivations/README.md) | 方程推导 |
| [05_consistency](05_consistency/README.md) | 证明与理论一致性 |
| [06_predictions](06_predictions/README.md) | 可检验预测 |
| [07_computation](07_computation/README.md) | 计算与复现 |
| [08_data](08_data/README.md) | 数据与溯源 |
| [09_validation](09_validation/README.md) | 数值验证与观测检验 |
| [10_uncertainty](10_uncertainty/README.md) | 不确定度与稳健性 |
| [11_falsification](11_falsification/README.md) | 反例与证伪 |
| [12_conclusions](12_conclusions/README.md) | 结论与开放问题 |
| [13_publications](13_publications/README.md) | 论文与传播 |
| [14_review](14_review/README.md) | 评审与独立复现 |
| [15_releases](15_releases/README.md) | 发布与长期保存 |
| [90_archive](90_archive/README.md) | 历史与终止路线 |

[资料关联](sources.md) · [证据登记](claims.csv) · [总流程](../../00_governance/WORKFLOW.md)
