# 项目治理

| 位置 | 职责 |
|---|---|
| [design](design/README.md) | 体系拆分依据、目录设计与扩展分析 |
| [audits](audits/README.md) | 自动目录审计、执行记录与本次迁移映射 |
| [catalog](catalog/README.md) | 自动生成的全量文件导航 |
| tools/ | 登记、导航和审计生成工具 |
| layout.json、module_types.json、system_registry.json | 结构契约、类型定义及自动体系总登记 |
| [贡献](CONTRIBUTING.md)、[流程](WORKFLOW.md)、[验证](VALIDATION.md) | 当前研究操作规则 |

[体系入口](../01_systems/README.md) · [全球研究目录](../05_global_research/README.md) · [迁移说明](MIGRATION_GUIDE.md)

机器契约保留稳定路径，设计说明与审计输出已拆分到独立子目录。历史迁移证据继续保存在 90_archive；全球文献、翻译和协作材料进入 05_global_research。
