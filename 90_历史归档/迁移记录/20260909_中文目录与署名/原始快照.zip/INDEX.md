# 目录总导航

```text
openuft/
├── 00_governance/              项目规则与机器契约
│   ├── design/                 体系边界与目录设计
│   ├── audits/                 目录审计与执行记录
│   ├── catalog/                自动文件索引
│   └── tools/                  生成与检查工具
├── 01_systems/                 独立研究体系与方向
│   ├── _template/              新体系模板
│   └── <stable_system_id>/     每个体系独立的 17 个研究阶段
├── 02_shared/                  共用方法、参考材料、计算与基准
├── 03_comparative/             跨体系比较、原著合集与综合研究
├── 04_publications/            公共综述、报告与可视化
├── 05_global_research/         全球研究与协作
│   ├── 01_literature/          外部原始文献登记
│   ├── 02_coverage/            研究路线覆盖及缺口
│   ├── 03_translations/        译文与源版本对应
│   └── 04_collaboration/       国际协作与审查协调
├── 90_archive/                 历史原件与迁移快照
└── 99_inbox/                   归属未定材料
```

[体系分类](01_systems/TYPE_INDEX.md) · [全球研究](05_global_research/README.md) · [全部目录审计](00_governance/audits/DIRECTORY_AUDIT.md) · [全量文件索引](00_governance/catalog/material_catalog.md)

材料归属顺序：具体体系优先；可复用工具进入共享层；明确跨体系比较进入比较层；外部文献及协作进入全球研究层；归属不明进入收件区。不要按国家、语言或类型复制完整体系。
