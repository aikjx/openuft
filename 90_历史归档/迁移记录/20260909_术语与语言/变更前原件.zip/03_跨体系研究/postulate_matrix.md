# 跨体系公设对照矩阵

本文件是 openuft 的**视图层整理**，不移动任何目录。它把 16 个体系（按 `system.json` 登记）的公设、本体与版本线横向比对，服务于"按原始假设归属、关键词命中只算候选关联"的判定原则。

命名规则（唯一成文来源 `00_项目治理/WORKFLOW.md`）：目录/ID/编号用英文 snake_case（稳定身份）；标题与正文用中文（人类可读）。所有链接指向体系入口，详情见各体系 `02_基础公设/postulates.md`。

## 1. 一页式对照表

| 体系 (ID) | 类型 | 本体主张 | 核心公设 | c / ħ / e 地位 | 版本线 | 失效阈值 | 详情 |
|---|---|---|---|---|---|---|---|
| [p01 空间压缩](../01_独立体系/P01_空间压缩与密度本体/README.md) | hypothesis | 待建模方向 | 无 | — | — | — | 方向占位 |
| [p02 物质源](../01_独立体系/P02_物体驱动与源场本体/README.md) | hypothesis | 待建模方向 | 无 | — | — | — | 方向占位 |
| [p03 规范统一](../01_独立体系/P03_规范对称统一候选/README.md) | hypothesis | 待建模方向 | 无 | — | — | — | 方向占位 |
| [p04 量子涌现](../01_独立体系/P04_量子结构与时空涌现候选/README.md) | observation | 待建模方向 | 无 | — | — | — | 方向占位 |
| [s01 螺旋三重奏](../01_独立体系/S01_螺旋三重奏与谱几何/README.md) | mathematical_framework | 无（纯数学） | A1–A3 数学设定 | 不涉及 | R1–R11 审计 | 无需（框架） | [postulates](../01_独立体系/S01_螺旋三重奏与谱几何/02_基础公设/postulates.md) |
| [s02 ZUFT统一力](../01_独立体系/S02_ZUFT空间运动与统一力/README.md) | candidate_theory | 统一力动力学（无几何本体） | A1–A4 | c 为速度上限 | D5 | 无 | [postulates](../01_独立体系/S02_ZUFT空间运动与统一力/02_基础公设/postulates.md) |
| [s03 GAQ 几何原子](../01_独立体系/S03_GAQ几何原子与作用量子/README.md) | candidate_theory | 离散几何元胞 | A1–A5 | c=L_p/T_p 几何化；ħ 公理 | v1 | 无 | [postulates](../01_独立体系/S03_GAQ几何原子与作用量子/02_基础公设/postulates.md) |
| [s04 IEG 信息熵引力](../01_独立体系/S04_IEG信息熵引力/README.md) | candidate_theory | 几何信息场 | A1–A3 | 不涉及 | GAQ v3 | 无 | [postulates](../01_独立体系/S04_IEG信息熵引力/02_基础公设/postulates.md) |
| [s05 HDU 高维统一](../01_独立体系/S05_HDU高维紧致化统一/README.md) | candidate_theory | 11 维 M 理论嵌入 | A1–A3 | 不涉及 | GAQ v3 | 无 | [postulates](../01_独立体系/S05_HDU高维紧致化统一/02_基础公设/postulates.md) |
| [s06 TCL 拓扑手征](../01_独立体系/S06_TCL拓扑手征锁定/README.md) | candidate_theory | Cl(4,4) 边界态 | A1–A3 | 不涉及 | GAQ v3 | 无 | [postulates](../01_独立体系/S06_TCL拓扑手征锁定/02_基础公设/postulates.md) |
| [s07 GAQ 复曲率](../01_独立体系/S07_GAQ复曲率融合体系/README.md) | composite_candidate | 复曲率 Ξ=κ+iτ | A1–A5 | c、ħ、e 三公理常数 | v4 | 无 | [postulates](../01_独立体系/S07_GAQ复曲率融合体系/02_基础公设/postulates.md) |
| [s08 GAQ 常数几何化](../01_独立体系/S08_GAQ常数几何化体系/README.md) | extension_candidate | 复曲率（继承）+ c/ħ 几何化 | A1–A5 | c、ħ 降为几何桥梁；e 降为导出量 | v5 | 无 | [postulates](../01_独立体系/S08_GAQ常数几何化体系/02_基础公设/postulates.md) |
| [s09 GAQ 质量谱](../01_独立体系/S09_GAQ粒子质量谱体系/README.md) | extension_candidate | SO(3) 代结构 | A1–A3 | 继承 v5 | v6 | 无 | [postulates](../01_独立体系/S09_GAQ粒子质量谱体系/02_基础公设/postulates.md) |
| [s10 频率本源](../01_独立体系/S10_频率本源与复螺旋宇宙/README.md) | candidate_theory | 振动/频率（螺旋是轨迹） | A1–A3 | c 为**上限** v≤c | 原著 2026 | 无 | [postulates](../01_独立体系/S10_频率本源与复螺旋宇宙/02_基础公设/postulates.md) |
| [s11 GMUFT 几何耦合](../01_独立体系/S11_GMUFT几何自由度与耦合/README.md) | candidate_framework | 四几何自由度 | A1–A4 | 不涉及 | 全维分析 | 无（场方程 OPEN） | [postulates](../01_独立体系/S11_GMUFT几何自由度与耦合/02_基础公设/postulates.md) |
| [s12 空间光速螺旋](../01_独立体系/S12_空间光速螺旋统一体系/README.md) | candidate_theory | 空间以光速螺旋运动 | A1–A4（含借用 S02） | v≡c 恒等约束 | v6.0-20260906 | 仅人工场设计级 | [postulates](../01_独立体系/S12_空间光速螺旋统一体系/02_基础公设/postulates.md) |

## 2. 最易混淆的五组

1. **s10 vs s12（都叫"螺旋"）**：s10 本体是振动/频率，螺旋是振动轨迹，c 是上限 `v ≤ c`；s12 本体是空间以光速运动，c 是恒等约束 `v ≡ c`。共用 `√(κ²+τ²)=ω/c` 骨架，但互不认证。
2. **s07 vs s08（GAQ v4 vs v5）**：同一复曲率本体，关键差异是 c、ħ、e 的地位——v4 为三条公理常数，v5 把 c、ħ 降为几何桥梁、e 降为导出量。这是版本演进而非独立体系。
3. **s06 vs s09（代结构两版）**：都用 `π₃(SU(3))×ℤ₂^chiral=6`；s06 用 Cl(4,4) 边界态，s09 用 SO(3) 本征方向。同谱系不同阐述。
4. **s01 vs s12/s10（数学 vs 本体）**：s01 是纯数学框架，三重奏 `κ²+τ²=(ω/v)²` 是导出定理而非公设；s12/s10 借用数学语言但各自主张本体，数学成立不转移证据。
5. **s02 vs s12（统一力方程）**：s12 借用 s02 的 `P=m(c−v)`、`F=dP/dt`（登记为 S12-A4 借用项），但 s02 不主张几何本体。

## 3. 诚实结论（跨体系）

- **失效阈值几乎全缺**：16 个体系中，仅 s12 的人工场条目有原文阈值（5 预言 / 4 证伪）；其余公设均无独立可证伪条件，当前只能作 conjecture 登记。
- **GAQ 谱系是重灾区**：s03→s07→s08→s09 是同一研究的 v1→v4→v5→v6 演进，公设地位（尤其 c/ħ/e）逐版变化。按原始假设各自归属，不得假设版本间公设"完全相同"。
- **p01–p04 是方向占位**：无公设、无证据，不构成体系，仅供后续建模立项。
- **均未经独立复现**：各体系数值精算多属代数恒等与 CODATA 回算，仓库内 `07_计算复现/运行记录` 普遍空缺，证据等级不应高于 conjecture / numerical_check（未复现）。
