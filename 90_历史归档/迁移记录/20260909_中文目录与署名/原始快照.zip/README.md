# OpenUFT · 全球开放统一场论研究

[English](README.en.md) · [体系区分与全球协作布局](05_global_research/ROADMAP.md) · [参与贡献](CONTRIBUTING.md)

面向全球参与者组织独立理论候选、数学框架与可复核研究。现有模块是本仓库的研究登记，不代表全球理论全集，也不表示统一场论已获证实。

[按模块类型浏览](01_systems/TYPE_INDEX.md) · [全部独立体系](01_systems/README.md) · [最优性与可持续扩展分析](00_governance/design/SCALABILITY_REVIEW.md)

每个大体系拥有稳定主目录及独立的公设、推导、代码、数据、证据、论文和发布入口。模块按数学框架、理论候选、待完备框架、组合候选、扩展分支、待建模方向分类。类型、工作状态和科学证据分别管理。

当前体系名单从各自 system.json 自动生成，类型变化不搬动原路径，新增体系不要求重排已有目录。

## 项目层次

| 目录 | 用途 |
|---|---|
| [00_governance](00_governance/README.md) | 规则、类型字典、登记和结构审查 |
| [01_systems](01_systems/README.md) | 各大体系独立研究与完整生命周期 |
| [02_shared](02_shared/README.md) | 共用方法、常数和经典基准 |
| [03_comparative](03_comparative/README.md) | 跨体系比较与精确来源引用 |
| [04_publications](04_publications/README.md) | 跨体系综述和公共展示 |
| [05_global_research](05_global_research/README.md) | 全球文献、覆盖矩阵、翻译与国际协作 |
| [90_archive](90_archive/README.md) | 历史资料与迁移恢复证据 |
| [99_inbox](99_inbox/README.md) | 尚未确定归属的输入 |

[快速开始](QUICKSTART.md) · [逐目录分析](00_governance/audits/DIRECTORY_AUDIT.md) · [全量文件索引](00_governance/catalog/material_catalog.md) · [历史拆分依据](00_governance/design/INDEPENDENT_SYSTEMS_DESIGN.md)

结构检查：`python -B verify.py`。结构完整与计算成功均不表示统一场论成立。
