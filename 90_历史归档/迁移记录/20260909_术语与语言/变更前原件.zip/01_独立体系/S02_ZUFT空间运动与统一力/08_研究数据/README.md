# 08_研究数据

所属独立体系：[ZUFT空间运动与统一力](../README.md)。

保存原始/派生数据、来源、许可、单位和处理链；一份数据只有一个主位置。

[身份与基础前提](../system.json) · [来源](../sources.md) · [证据登记](../claims.csv)

现有条目：

- [data_registry.csv](data_registry.csv)
- [外部数据](外部数据)
- [处理后数据](处理后数据)
- [原始数据](原始数据)
