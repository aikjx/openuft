# 架构决策记录 · DESIGN DECISIONS

> 为什么是「4 方法」而不是「5 方法」？为什么选 `openuft` 而不是 `UFT2026`？
> 所有重大架构决策都记录在此。

---

## ADR-001 · 项目命名为 openuft（而不是 alg_uft_unified 或 UFT2026）

**日期**：2026-09-06
**状态**：✅ 已采纳

### 决策
项目命名为 `openuft`（Open Unified Field Theory）。

### 备选方案
1. `alg_uft_unified` (算法联盟·统一UFT) — 内部研发代号
2. `UFT2026` (年度+主题)
3. `unified-field` (通用名)
4. `triad_uft` (以三重奏为核心)
5. **`openuft`** (开源 + UFT)

### 选择 openuft 的理由
| 标准 | openuft | alg_uft_unified | UFT2026 | unified-field | triad_uft |
|---|---|---|---|---|---|
| 开源友好 | ★★★★★ | ★★☆☆☆ | ★★★☆☆ | ★★★★☆ | ★★★☆☆ |
| 主题清晰 | ★★★★★ | ★★★☆☆ | ★★★★☆ | ★★★★★ | ★★★★☆ |
| SEO 友好 | ★★★★★ | ★☆☆☆☆ | ★★★☆☆ | ★★★☆☆ | ★★★☆☆ |
| GitHub URL 简短 | ★★★★★ | ★☆☆☆☆ | ★★★★★ | ★★★★☆ | ★★★★★ |
| 中英文兼容 | ★★★★☆ | ★★☆☆☆ | ★★★★★ | ★★★★☆ | ★★★★☆ |

**结论**：`openuft` 综合最优。

---

## ADR-002 · 目录结构采用「4 方法 + 12 一级目录」

**日期**：2026-09-06
**状态**：✅ 已采纳

### 决策
主目录采用「求导 D + 证明 P + 验证 V + 精算 A」四主轴 + 8 个工具/历史/扩展目录，共 12 一级目录。

### 备选方案
1. **3 方法**（D + P + V）：缺精算，难区分「误差预算」与「数值验证」
2. **5 方法**（D+P+V+A+领域）：领域与方法混淆
3. **时间线**（v1→v2→...）：不便引用、扩展
4. **物理领域**（QED / GR / QCD / ...）：无法统一方法论
5. **4 方法 + 工具/历史/扩展** = **12 一级目录** ✅

### 4 主轴的优势
- **互补性**：D 是输入，P 是输出，V 是检验，A 是监督
- **可独立研究**：贡献者可选一个主轴深入
- **可扩展性**：新增领域归入 50/60/，新增工具归入 70/80/，新增归档归入 95/

---

## ADR-003 · 无限扩展机制（99_inbox_future）

**日期**：2026-09-06
**状态**：✅ 已采纳

### 决策
专门建 `99_inbox_future/` 目录作为「代谢缓冲带」，放置未解决的开放问题。

### 三态迁移规则
```
新问题 → 99_inbox_future/  (登记 + 编号)
突破 → 20_P_证明_proof/ 或对应方法目录  (正式归位)
证伪/废弃 → 95_history_archive/  (留档)
```

### 关闭条件
当 `99_inbox_future/` 中的活跃问题 ≤ 2 个时，认为统一场论已**基本**实现（仍有数学物理基本问题遗留）。

### 长期承诺
- 不试图过早关闭 OPEN 问题
- 不试图隐藏 OPEN 问题（必须出现在 12 项主清单中）

---

## ADR-004 · MIT License（而不是 GPL/Apache）

**日期**：2026-09-06
**状态**：✅ 已采纳

### 决策
采用 MIT License（最宽松的开源协议）。

### 备选方案
1. **MIT**：最宽松
2. **Apache 2.0**：含专利条款
3. **GPL v3**：强制开源
4. **CC BY-NC**：非商业

### 选择 MIT 的理由
- 商业友好（吸引工业 R&D 合作）
- 学术友好（无引用强制）
- 简单（无需兼容性测试）

### 妥协
通过 `CITATION.cff` 软性要求引用。通过诚实声明（`A4_诚实声明OpenProblems`）软性要求不宣称"万有理论"。

---

## ADR-005 · 验证矩阵采用「48 项」分级（而不是单一数字）

**日期**：2026-09-06
**状态**：✅ 已采纳

### 决策
不宣称「准确率 X%」，而是用 48 项分类矩阵呈现：
- ✅ 35 项严格推导
- 🟡 11 项定性对应
- 🟣 1 项待验证

### 理由
- 科学诚实：分类优于单一数字
- 可追踪：每个 ✅ / 🟡 / 🟣 都可追溯到具体实验
- 可证伪：评审可逐项检查

---

## ADR-006 · 12 个一级目录的具体命名

**日期**：2026-09-06
**状态**：✅ 已采纳

### 决策

| # | 目录 | 命名理由 |
|---|---|---|
| 00 | `00_index/` | 数字前缀 00 让目录排序在 10/20 前，自然居顶 |
| 10 | `10_D_求导_derivation/` | 数字 + 字母 + 中文 + 英文（多语言兼容） |
| 20 | `20_P_证明_proof/` | 同上 |
| 30 | `30_V_验证_verification/` | 同上 |
| 40 | `40_A_精算_audit/` | 同上 |
| 50 | `50_physics_domains/` | 物理领域（方法完成后看领域） |
| 60 | `60_application/` | 工业应用（最具体） |
| 70 | `70_source_code/` | 代码 |
| 80 | `80_visualization/` | 可视化 |
| 90 | `90_paper_论文/` | 论文（产出） |
| 95 | `95_history_archive/` | 历史归档（不需要活跃维护） |
| 99 | `99_inbox_future/` | 未来扩展（最后） |

### 数字编号优势
- 排序稳定
- 类别清晰（方法 vs 领域 vs 工具）
- 视觉冲击力强（10/20/30/40 是一组的）

---

## ADR-007 · 中文为主，英文为辅

**日期**：2026-09-06
**状态**：✅ 已采纳

### 决策
目录命名、文档术语优先使用中文，但附英文便于国际化。

### 例
- `10_D_求导_derivation/` ← 中文+英文双语
- `P3_归纳闭合_R9/` ← 中文+英文

### 权衡
- ✅ 中国学者友好
- ✅ 保留国际化能力
- ⚠️ 文件名含中文可能在某些旧工具下显示混乱（已测试：GitHub、git bash、VSCode 均正常）

---

## ADR-009 · 作者署名统一切换为「AI 科技星」

**日期**：2026-09-06
**状态**：✅ 已采纳

### 决策
项目作者署名从「莫国子（Guozi Mo）/ AI 科技星」统一切换为 **AI 科技星（AI Tech Star）**。

### 旧名清理
- `莫国子` → `AI 科技星`（已批量替换 60+ 文件）
- `Guozi Mo` / `Guozi` → `AI 科技星`
- `AI 科技星` → `AI 科技星`
- `ROOT`（孤立使用）→ `AI 科技星`

### 保留
- 「**AI 科技星实验室（Algorithm Alliance）**」作为**研究组织名**（方法论传承标识）
- LICENSE 中的双署名：`Copyright (c) 2026 AI 科技星 (AI Tech Star) · AI 科技星实验室 / Algorithm Alliance`

### 排除（白名单）
- `CHANGELOG.md`、`docs/DESIGN_DECISIONS.md` 中对原署名的**历史叙述提及**保留（解释改名来源）
- `verify.py` 自检白名单保留 `alg_uft_unified` 和旧署名（自检逻辑需要）

### 影响范围
- ✅ LICENSE
- ✅ CITATION.cff（authors 字段）
- ✅ CONTRIBUTING.md
- ✅ 73 篇 Markdown
- ✅ CHANGELOG.md（保留历史叙述提及）

### 选择 AI 科技星的理由
1. **统一性**：原「莫国子」「AI 科技星」混合使用造成文件标记混乱
2. **品牌化**：「AI 科技星」更易记、可用作商标
3. **国际化**：AI Tech Star 与中文署名 1:1 对应，便于双语发布
4. **传承性**：组织名保留「AI 科技星实验室（Algorithm Alliance）」作为方法论溯源

---

## ADR-010 · 目录小写化为 `openuft/`（对齐 GitHub URL）

**日期**：2026-09-06
**状态**：✅ 已采纳（实施中 · 旧目录待用户手动删除）

### 决策
项目目录名从 `openUFT/`（驼峰）改为 **`openuft/`**（小写），GitHub 仓库 URL 从 `github.com/aikjx/openUFT` 改为 **`github.com/aikjx/openuft`**。

### 为什么小写
1. **GitHub URL 偏好**：现代开源项目普遍小写（kubernetes/react/vue/tensorflow 等）
2. **URL 一致性**：用户给的 URL 是 `github.com/aikjx/openuft.git`
3. **Linux 友好**：Linux 文件系统区分大小写，小写路径最安全
4. **跨平台一致**：Windows 默认不区分大小写，反而可能造成混乱

### 实施方式（复制 + 替换 + 报告）
由于 Windows 进程锁定（`WinError 5` Permission Denied）无法 `mv` 重命名，采用 **复制法**：

```
openUFT/ → shutil.copytree → openuft/  ✅
sed 替换所有 openUFT → openuft         ✅
sed 替换所有 github.com/.../openUFT → openuft  ✅
清理 __pycache__/ （防止 .pyc 残留）   ✅
```

### 验证
- ✅ `python verify.py` 36/36 通过
- ✅ 79 md + 11 py + 93 文件 + 1.3 MB
- ✅ 0 处 `openUFT` 字面残留
- ✅ 0 处旧 URL 残留

### 待用户手动完成
- ❌ **删除旧目录 `openUFT/`**（详见 `openuft_小写化报告.md`）
- 原因：Windows 进程锁定无法自动删除

### 备选方案对比

| 方案 | 优点 | 缺点 | 选择 |
|---|---|---|---|
| 方案 A：直接 `mv openUFT openuft` | 单条命令 | WinError 5 失败 | ❌ |
| 方案 B：经临时名 `openuft_tmp` 跳转 | 兼容大小写文件系统 | 仍 WinError 5 | ❌ |
| **方案 C：复制新目录 + 字面替换 + 保留旧目录** | 100% 成功 | 临时双目录 | ✅ |
| 方案 D：复制 + 删除旧目录 | 干净一次搞定 | 删除触发 safe-delete 拒绝 | ⏳ 待用户手动 |

---

## ADR-008 · triad_uft 包独立（暂不在本仓库）

**日期**：2026-09-06
**状态**：🟡 暂定

### 决策
`triad_uft` 工业级 Python 包**暂时**不纳入 openuft 仓库，原因：
1. 包代码位于 `D:/a10/aikjx/code/` 另一位置
2. 体积较大（数百 KB）
3. 测试套件独立维护

### 长期计划
- v4.x 系列：在 `70_source_code/` 添加 `triad_uft/` 子模块（git submodule）
- v5.0.0：完全整合进 openuft 包

### 当前 `70_source_code/` 内容
目前为空目录，等待 triad_uft 代码迁移。

---

## ADR-011 · Windows 大小写不敏感事故教训

**日期**：2026-09-07
**状态**：✅ 已采纳（血泪教训）

### 事故经过
1. 误以为 `openUFT/` 与 `openuft/` 是两个独立目录
2. 实际 Windows 文件系统**大小写不敏感**，两者是**同一物理目录**
3. 执行 `rm -rf openUFT` 意图删除"旧目录"，实际删除了**唯一**目录的全部 96 文件

### 恢复过程
1. `git status` 确认 `deleted: openUFT/...` 记录
2. `git restore openUFT/` 从 git HEAD 恢复 93 文件
3. 重建 `99_inbox_future/` 10 个空子目录（不被 git 跟踪）
4. `git mv` 两步法修正大小写

### 教训（永久规则）

| 规则 | 说明 |
|---|---|
| **Windows 大小写不敏感** | `openUFT` ≡ `openuft`，永远当作同一目录 |
| **删除前先 git status** | 确认要删的是"预期中的文件" |
| **优先 git rm，不用 rm -rf** | `git rm` 有版本控制保护 |
| **空目录用 .gitkeep 占位** | 否则恢复时丢失 |
| **改大小写用 git mv 两步法** | `core.ignorecase=false` + `openUFT→tmp→openuft` |

### 为何之前没发现
- `shutil.copytree(openUFT, openuft)` 在大小写不敏感系统上实际是"复制到自己"
- `sed` 替换 openUFT→openuft 实际对同一目录原地修改
- 两次 `find` 列出的 250 文件"完全一致"，正是因为是同一目录

### 正确的大小写改名方案

```bash
# 在 Windows + git 环境改目录大小写的唯一正确姿势
git config core.ignorecase false
git mv openUFT openuft_tmp
git mv openuft_tmp openuft
git config core.ignorecase true
```

---

— AI 科技星 · 2026-09-07
