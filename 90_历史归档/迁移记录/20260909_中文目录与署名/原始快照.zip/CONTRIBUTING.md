# Contributing / 参与研究

[中文研究约定](00_governance/CONTRIBUTING.md) · [English introduction](README.en.md) · [体系边界与全球协作](05_global_research/ROADMAP.md)

Contributions in Chinese or English are welcome. Include a short English summary when possible so international readers can identify the question and review scope.

1. Identify a stable module ID and assumption revision. Unattributed material belongs in `99_inbox`; do not merge theories merely because they share formulas.
2. Cite primary sources with author, title, year, persistent identifier where available, and precise section or equation. State whether the material is a quotation, translation, derivation or interpretation, and record reuse permission for external material.
3. Register claims in the module's `claims.csv`. Separate mathematical results, numerical checks and empirical evidence. Include assumptions, uncertainties and negative results; do not fill missing evidence with success labels.
4. For computations, record the command, runtime and dependencies, configuration, input provenance, random seed when relevant, output and limitations. A successful run alone is not physical confirmation.
5. For comparisons, state each model's assumptions, observables, units and regime. Record unresolved incompatibilities. Related modules are not automatically logical dependencies.
6. For translations, record the original path and revision, language, translator and review status. Retain stable IDs and equations. Review scientific content separately from language quality.
7. Run the commands in the English introduction. For catalog changes, regenerate derived views before verification. In the pull request, list affected modules, actual checks and remaining uncertainty.

Review contributions on reproducibility and evidence, independent of language, country or affiliation. Disclose relevant conflicts of interest; criticize claims rather than people. Do not claim reviewer approval without a traceable review record.
