# OpenUFT · Open research on unified field theories

[中文](README.md) · [Research modules](01_systems/README.en.md) · [Contribute](CONTRIBUTING.md) · [Global collaboration plan / 全球协作](05_global_research/ROADMAP.md)

OpenUFT organizes independent research candidates, mathematical frameworks and open questions. Each module keeps its own assumptions, derivations, predictions, computations, data, reviews and releases. Inclusion does not establish a theory, imply endorsement, or demonstrate experimental confirmation. Historical claims must be assessed against their actual evidence.

## Find your entry point

| Area | Purpose |
|---|---|
| [Governance](00_governance/README.md) | Classification, provenance and review rules |
| [Independent modules](01_systems/README.en.md) | Stable identities and separate assumptions |
| [Shared resources](02_shared/README.md) | Methods, reference material and baselines |
| [Comparative research](03_comparative/README.md) | Comparisons with explicit source attribution |
| [Publications](04_publications/README.md) | Cross-module summaries and presentation |
| [Global research](05_global_research/README.md) | External literature, coverage, translations and collaboration |
| [Archive](90_archive/README.md) | Historical records and migration snapshots |
| [Inbox](99_inbox/README.md) | Material awaiting attribution |

## Reproduce the repository checks

From the OpenUFT directory, using Python 3:

```sh
python -B verify.py
python -B -m unittest discover -s 00_governance/tools -p "test_*.py"
```

These commands validate repository structure and catalog behavior using the Python standard library. They do not reproduce every physics calculation. Computational modules have their own environments and validation requirements; record dependencies, commands, inputs and outputs for any scientific result.

When adding or reclassifying a module, edit its `system.json`, then run:

```sh
python -B 00_governance/tools/module_catalog.py refresh
python -B 00_governance/tools/refresh_catalog.py
python -B verify.py
```

English navigation is available; most research source texts remain Chinese. Translations should identify the source revision and preserve equations, assumptions and uncertainty. This repository does not yet demonstrate comprehensive worldwide research coverage or an established international reviewer network.
