# 07_computation

所属独立体系：[GAQ 几何原子与作用量子](../README.md)。

管理本体系源码、配置、测试与运行；共同基准显式声明依赖，专属算法不得放入公共总筐。

[身份与基础前提](../system.json) · [来源](../sources.md) · [证据登记](../claims.csv)

现有条目：

- [configs](configs/)
- [notebooks](notebooks/)
- [runs](runs/)
- [src](src/)
- [tests](tests/)
