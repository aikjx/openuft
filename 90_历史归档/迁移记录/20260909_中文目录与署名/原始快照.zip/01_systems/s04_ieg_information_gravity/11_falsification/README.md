# 11_falsification

所属独立体系：[IEG 信息熵引力](../README.md)。

保留反例、负结果、预设失效阈值和范围收缩，不能因结果不利而删除。

[身份与基础前提](../system.json) · [来源](../sources.md) · [证据登记](../claims.csv)

当前尚无本阶段独立产物；不因目录存在而标记完成。
