# Research modules

[English introduction](../README.en.md) · [中文分类](TYPE_INDEX.md)

Generated from system.json. Original titles are retained to avoid unreviewed translations. Stable IDs are language independent. Type, work status and scientific evidence are separate; registration is not validation.

| Stable ID / entry | Original title | Module type | Work status |
|---|---|---|---|
| [p01_space_compression](p01_space_compression/README.md) | 空间压缩与密度本体 | `unformulated_direction` | `unformulated` |
| [p02_matter_source](p02_matter_source/README.md) | 物体驱动与源场本体 | `unformulated_direction` | `unformulated` |
| [p03_gauge_unification](p03_gauge_unification/README.md) | 规范对称统一候选 | `unformulated_direction` | `unformulated` |
| [p04_quantum_emergence](p04_quantum_emergence/README.md) | 量子结构与时空涌现候选 | `unformulated_direction` | `unformulated` |
| [s01_triad_kinematics](s01_triad_kinematics/README.md) | 螺旋三重奏与谱几何 | `mathematical_framework` | `unreviewed` |
| [s02_zhang_space_motion](s02_zhang_space_motion/README.md) | 张祥前空间运动与统一力 | `candidate_theory` | `unreviewed` |
| [s03_gaq_geometric_atom](s03_gaq_geometric_atom/README.md) | GAQ 几何原子与作用量子 | `candidate_theory` | `unreviewed` |
| [s04_ieg_information_gravity](s04_ieg_information_gravity/README.md) | IEG 信息熵引力 | `candidate_theory` | `unreviewed` |
| [s05_hdu_higher_dimensions](s05_hdu_higher_dimensions/README.md) | HDU 高维紧致化统一 | `candidate_theory` | `unreviewed` |
| [s06_tcl_topological_chirality](s06_tcl_topological_chirality/README.md) | TCL 拓扑手征锁定 | `candidate_theory` | `unreviewed` |
| [s07_gaq_complex_curvature](s07_gaq_complex_curvature/README.md) | GAQ 复曲率融合体系 | `composite_candidate` | `unreviewed` |
| [s08_gaq_geometrized_constants](s08_gaq_geometrized_constants/README.md) | GAQ 常数几何化体系 | `extension_candidate` | `unreviewed` |
| [s09_gaq_mass_spectrum](s09_gaq_mass_spectrum/README.md) | GAQ 粒子质量谱体系 | `extension_candidate` | `unreviewed` |
| [s10_frequency_helix_ontology](s10_frequency_helix_ontology/README.md) | 频率本源与复螺旋宇宙 | `candidate_theory` | `unreviewed` |
| [s11_gmuft_geometric_coupling](s11_gmuft_geometric_coupling/README.md) | GMUFT 几何自由度与耦合 | `candidate_framework` | `unreviewed` |
| [s12_light_speed_helix](s12_light_speed_helix/README.md) | 空间光速螺旋统一体系 | `candidate_theory` | `unreviewed` |

Types: mathematical framework; candidate theory; incomplete candidate framework; composite candidate; extension candidate; unformulated direction. The registry describes this repository, not an exhaustive survey of global physics research.
