# 常见问题

## 从哪里进入？

从 [各独立理论路线](../90_archive/layout_reviews/six_route_layout/README.md) 进入，与本体假设最接近的路线是主归属。

## 目录齐全是否意味着研究完成？

不是。目录和模板仅代表组织能力；system.json 的空值与未审查状态需要由真实研究填充。

## 跨体系材料放哪里？

共享方法放 02_shared，比较放 03_comparative，综合报告放 04_publications，无法确认的输入放 99_inbox。只设一个主文件，通过链接引用。

## 历史文件能恢复吗？

见 [迁移说明](MIGRATION_GUIDE.md)。迁移前 193 个文件保存在 ZIP 中，并有逐文件 SHA-256；恢复时先解压到独立目录核对。
