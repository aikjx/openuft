# docs/ · 全维度子文档目录

> 进一步细化的辅助文档。每个 .md 聚焦一个具体主题。

## 内容索引

| 文件 | 主题 | 受众 |
|---|---|---|
| [THEOREMS.md](THEOREMS.md) | 12 定理的数学展开（推导→证明→应用） | 理论物理学家 |
| [EXPERIMENTAL_CROSS_VALIDATION.md](EXPERIMENTAL_CROSS_VALIDATION.md) | 48 项验证矩阵的详细清单 | 实验/计算物理学家 |
| [OPEN_PROBLEMS.md](OPEN_PROBLEMS.md) | 12 项 OPEN 问题的更详细描述 | 所有人（**必读**） |
| [GLOSSARY.md](GLOSSARY.md) | 术语表（κ, τ, ω, v, R9, R10, R11, ...） | 新读者 |
| [MATHEMATICS.md](MATHEMATICS.md) | 核心数学结构（Cauchy、Clifford、谱、变分） | 数学家 |
| [NUMERICAL_METHODS.md](NUMERICAL_METHODS.md) | mpmath / sympy / 蒙特卡洛的具体使用方法 | 数值工程师 |
| [BIBLIOGRAPHY.md](BIBLIOGRAPHY.md) | 完整参考书目 + 链接 | 学术参考 |
| [DESIGN_DECISIONS.md](DESIGN_DECISIONS.md) | 架构决策记录（为什么 4 方法而不是 5） | 贡献者 |

## 如何新增 doc

1. 创建 `docs/YOUR_TOPIC.md`
2. 在此 INDEX.md 中添加一行
3. 在 `CHANGELOG.md` 添加 Unreleased 条目
4. 提交 Pull Request

— AI 科技星
