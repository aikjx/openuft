# 来源与边界

- [GAQ v3 原文独立章节；保留原主张，不表示审定](02_assumptions/source_chapter.md)
- [完整原著；章节为派生摘录](../../03_comparative/source_collections/GAQ_v3_three_systems.md)

归属按原文明示的前提与章节判断；目录独立不表示理论已经成立，也不表示各体系毫无亲缘关系。版本名称只在本体系内解释。
