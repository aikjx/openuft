# 02_assumptions

所属独立体系：[GAQ 复曲率融合体系](../README.md)。

明确原始公设、本体、自由度、尺度与适用边界；来源摘要不等于已完成公设审查。

[身份与基础前提](../system.json) · [来源](../sources.md) · [证据登记](../claims.csv)

本阶段产物：[公设清单与区分边界](postulates.md)。v4 复曲率五公理，与 v5 的 c/ħ 地位差异见文档。
